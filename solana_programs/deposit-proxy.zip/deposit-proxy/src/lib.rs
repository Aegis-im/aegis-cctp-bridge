use anchor_lang::prelude::*;
use anchor_spl::{
    associated_token::{get_associated_token_address, AssociatedToken},
    token::{Mint, Token, TokenAccount},
};

declare_id!("3HfHC6w4ttq7ZabPzoffs1GzBNBwbtZpaVvjVA1D6X6g");

#[program]
pub mod deposit_proxy {
    use super::*;

    pub fn initialize_vault(
        ctx: Context<InitializeVault>,
        vault_id: [u8; 32],
        destination_domain: u32,
        mint_recipient: Pubkey,
    ) -> Result<()> {
        require_keys_neq!(mint_recipient, Pubkey::default(), DepositProxyError::InvalidMintRecipient);

        let vault = &mut ctx.accounts.vault;
        vault.bump = ctx.bumps.vault;
        vault.authority_bump = ctx.bumps.vault_authority;
        vault.vault_id = vault_id;
        vault.burn_token_mint = ctx.accounts.burn_token_mint.key();
        vault.destination_domain = destination_domain;
        vault.mint_recipient = mint_recipient;
        Ok(())
    }

    pub fn deposit_for_burn_from_vault(ctx: Context<DepositForBurnFromVault>, amount: u64) -> Result<u64> {
        require_gt!(amount, 0, DepositProxyError::InvalidAmount);

        require_keys_eq!(
            ctx.accounts.vault.burn_token_mint,
            ctx.accounts.burn_token_mint.key(),
            DepositProxyError::InvalidBurnMint
        );

        let expected_ata = get_associated_token_address(
            &ctx.accounts.vault_authority.key(),
            &ctx.accounts.burn_token_mint.key(),
        );
        require_keys_eq!(
            expected_ata,
            ctx.accounts.vault_token_account.key(),
            DepositProxyError::InvalidVaultTokenAccount
        );
        require_keys_eq!(
            ctx.accounts.vault_token_account.owner,
            ctx.accounts.vault_authority.key(),
            DepositProxyError::InvalidVaultTokenAccountOwner
        );

        let cpi_program = ctx
            .accounts
            .token_messenger_minter_program
            .to_account_info();

        let cpi_accounts = token_messenger_minter::cpi::accounts::DepositForBurnContext {
            owner: ctx.accounts.vault_authority.to_account_info(),
            event_rent_payer: ctx.accounts.event_rent_payer.to_account_info(),
            sender_authority_pda: ctx.accounts.sender_authority_pda.to_account_info(),
            burn_token_account: ctx.accounts.vault_token_account.to_account_info(),
            message_transmitter: ctx.accounts.message_transmitter.to_account_info(),
            token_messenger: ctx.accounts.token_messenger.to_account_info(),
            remote_token_messenger: ctx.accounts.remote_token_messenger.to_account_info(),
            token_minter: ctx.accounts.token_minter.to_account_info(),
            local_token: ctx.accounts.local_token.to_account_info(),
            burn_token_mint: ctx.accounts.burn_token_mint.to_account_info(),
            message_sent_event_data: ctx.accounts.message_sent_event_data.to_account_info(),
            message_transmitter_program: ctx.accounts.message_transmitter_program.to_account_info(),
            token_messenger_minter_program: ctx
                .accounts
                .token_messenger_minter_program
                .to_account_info(),
            token_program: ctx.accounts.token_program.to_account_info(),
            system_program: ctx.accounts.system_program.to_account_info(),
        };

        let signer_seeds: &[&[&[u8]]] = &[&[
            b"vault_authority",
            ctx.accounts.vault.key().as_ref(),
            &[ctx.accounts.vault.authority_bump],
        ]];

        let cpi_ctx = CpiContext::new_with_signer(cpi_program, cpi_accounts, signer_seeds);

        let params = token_messenger_minter::token_messenger::instructions::DepositForBurnParams {
            amount,
            destination_domain: ctx.accounts.vault.destination_domain,
            mint_recipient: ctx.accounts.vault.mint_recipient,
        };

        token_messenger_minter::cpi::deposit_for_burn(cpi_ctx, params)
    }
}

#[derive(Accounts)]
#[instruction(vault_id: [u8; 32])]
pub struct InitializeVault<'info> {
    #[account(mut)]
    pub payer: Signer<'info>,

    #[account(
        init,
        payer = payer,
        space = Vault::LEN,
        seeds = [b"vault", vault_id.as_ref()],
        bump,
    )]
    pub vault: Account<'info, Vault>,

    /// CHECK: PDA signing authority for CPI.
    #[account(
        seeds = [b"vault_authority", vault.key().as_ref()],
        bump,
    )]
    pub vault_authority: UncheckedAccount<'info>,

    pub burn_token_mint: Account<'info, Mint>,

    #[account(
        init,
        payer = payer,
        associated_token::mint = burn_token_mint,
        associated_token::authority = vault_authority,
    )]
    pub vault_token_account: Account<'info, TokenAccount>,

    pub token_program: Program<'info, Token>,
    pub associated_token_program: Program<'info, AssociatedToken>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct DepositForBurnFromVault<'info> {
    pub event_rent_payer: Signer<'info>,

    #[account(seeds = [b"vault", vault.vault_id.as_ref()], bump = vault.bump)]
    pub vault: Account<'info, Vault>,

    #[account(seeds = [b"vault_authority", vault.key().as_ref()], bump = vault.authority_bump)]
    /// CHECK: PDA signing authority for CPI.
    pub vault_authority: UncheckedAccount<'info>,

    #[account(mut)]
    pub vault_token_account: Account<'info, TokenAccount>,

    // ---- TokenMessengerMinter depositForBurn CPI accounts ----

    /// CHECK: empty PDA from TokenMessengerMinter.
    pub sender_authority_pda: UncheckedAccount<'info>,

    pub token_messenger: Account<'info, token_messenger_minter::token_messenger::state::TokenMessenger>,

    pub remote_token_messenger:
        Account<'info, token_messenger_minter::token_messenger::state::RemoteTokenMessenger>,

    pub token_minter: Account<'info, token_messenger_minter::token_minter::state::TokenMinter>,

    #[account(mut)]
    pub local_token: Account<'info, token_messenger_minter::token_minter::state::LocalToken>,

    #[account(mut)]
    pub burn_token_mint: Account<'info, Mint>,

    #[account(mut)]
    pub message_transmitter: Account<'info, message_transmitter::state::MessageTransmitter>,

    /// CHECK: non-PDA uninitialized signer for MessageSent event data.
    #[account(mut)]
    pub message_sent_event_data: Signer<'info>,

    pub message_transmitter_program:
        Program<'info, message_transmitter::program::MessageTransmitter>,

    pub token_messenger_minter_program:
        Program<'info, token_messenger_minter::program::TokenMessengerMinter>,

    pub token_program: Program<'info, Token>,
    pub system_program: Program<'info, System>,
}

#[account]
pub struct Vault {
    pub bump: u8,
    pub authority_bump: u8,
    pub vault_id: [u8; 32],
    pub burn_token_mint: Pubkey,
    pub destination_domain: u32,
    pub mint_recipient: Pubkey,
}

impl Vault {
    pub const LEN: usize = 8 + 1 + 1 + 32 + 32 + 4 + 32;
}

#[error_code]
pub enum DepositProxyError {
    #[msg("Invalid amount")]
    InvalidAmount,

    #[msg("Invalid burn mint")]
    InvalidBurnMint,

    #[msg("Invalid mint recipient")]
    InvalidMintRecipient,

    #[msg("Invalid vault token account")]
    InvalidVaultTokenAccount,

    #[msg("Invalid vault token account owner")]
    InvalidVaultTokenAccountOwner,
}
